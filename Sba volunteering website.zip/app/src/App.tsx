import { useState, useRef, useCallback, useEffect } from 'react'
import { gsap } from 'gsap'
import {
  ChevronDown,
  Upload,
  X,
  Mail,
  Phone,
  CheckCircle2,
  FileText,
  Link2,
  Loader2,
  Globe,
} from 'lucide-react'

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
type ContactMethod = 'email' | 'whatsapp' | null

interface FormData {
  fullName: string
  skills: string
  contactMethod: ContactMethod
  email: string
  whatsapp: string
  file: File | null
  links: string[]
}

interface FormErrors {
  fullName?: string
  skills?: string
  contactMethod?: string
  email?: string
  whatsapp?: string
  file?: string
  links?: string[]
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const FORMSPREE_ENDPOINT = 'https://formspree.io/f/mnnnrnqo'

const INITIAL_FORM: FormData = {
  fullName: '',
  skills: '',
  contactMethod: null,
  email: '',
  whatsapp: '',
  file: null,
  links: [''],
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
function App() {
  const [form, setForm] = useState<FormData>(INITIAL_FORM)
  const [errors, setErrors] = useState<FormErrors>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [isDragOver, setIsDragOver] = useState(false)

  const formRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const fieldsRef = useRef<HTMLDivElement>(null)

  /* ---- GSAP entrance animation for form fields ---- */
  useEffect(() => {
    if (!fieldsRef.current) return
    const fields = fieldsRef.current.querySelectorAll('.form-field')
    gsap.set(fields, { opacity: 0, y: 20 })

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            gsap.to(fields, {
              opacity: 1,
              y: 0,
              duration: 0.5,
              stagger: 0.08,
              ease: 'power3.out',
            })
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.1 }
    )

    observer.observe(fieldsRef.current)
    return () => observer.disconnect()
  }, [isSuccess])

  /* ---- GSAP scroll-down chevron ---- */
  useEffect(() => {
    const chevron = document.querySelector('.scroll-chevron')
    if (!chevron) return
    const tl = gsap.timeline({ repeat: -1 })
    tl.to(chevron, { y: 8, opacity: 0.5, duration: 0.75, ease: 'sine.inOut' })
      .to(chevron, { y: 0, opacity: 1, duration: 0.75, ease: 'sine.inOut' })
    return () => { tl.kill() }
  }, [])

  /* ---- Form handlers ---- */
  const updateField = <K extends keyof FormData>(
    field: K,
    value: FormData[K]
  ) => {
    setForm((prev) => ({ ...prev, [field]: value }))
    // Clear error for this field
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev }
        delete next[field]
        return next
      })
    }
  }

  const handleContactMethodSelect = (method: ContactMethod) => {
    updateField('contactMethod', method)
    // Clear the other contact field's error
    setErrors((prev) => ({
      ...prev,
      contactMethod: undefined,
      email: undefined,
      whatsapp: undefined,
    }))
  }

  const handleFileDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragOver(false)
      const droppedFile = e.dataTransfer.files[0]
      if (droppedFile && droppedFile.type === 'application/pdf') {
        if (droppedFile.size <= 5 * 1024 * 1024) {
          updateField('file', droppedFile)
          setErrors((prev) => ({ ...prev, file: undefined }))
        } else {
          setErrors((prev) => ({
            ...prev,
            file: 'File size must be less than 5MB',
          }))
        }
      } else if (droppedFile) {
        setErrors((prev) => ({ ...prev, file: 'Only PDF files are allowed' }))
      }
    },
    []
  )

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      if (selectedFile.type === 'application/pdf') {
        if (selectedFile.size <= 5 * 1024 * 1024) {
          updateField('file', selectedFile)
          setErrors((prev) => ({ ...prev, file: undefined }))
        } else {
          setErrors((prev) => ({
            ...prev,
            file: 'File size must be less than 5MB',
          }))
        }
      } else {
        setErrors((prev) => ({ ...prev, file: 'Only PDF files are allowed' }))
      }
    }
  }

  const removeFile = () => {
    updateField('file', null)
    if (fileInputRef.current) fileInputRef.current.value = ''
  }

  const addLinkField = () => {
    if (form.links.length < 3) {
      updateField('links', [...form.links, ''])
    }
  }

  const updateLink = (index: number, value: string) => {
    const newLinks = [...form.links]
    newLinks[index] = value
    updateField('links', newLinks)
  }

  const removeLink = (index: number) => {
    const newLinks = form.links.filter((_, i) => i !== index)
    if (newLinks.length === 0) newLinks.push('')
    updateField('links', newLinks)
  }

  /* ---- Validation ---- */
  const validate = (): boolean => {
    const newErrors: FormErrors = {}

    if (!form.fullName.trim() || form.fullName.trim().length < 2) {
      newErrors.fullName = 'Please enter your full name (at least 2 characters)'
    }

    if (!form.skills.trim() || form.skills.trim().length < 10) {
      newErrors.skills = 'Please describe your skills (at least 10 characters)'
    }

    if (!form.contactMethod) {
      newErrors.contactMethod = 'Please select a contact method'
    } else if (form.contactMethod === 'email') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!form.email.trim() || !emailRegex.test(form.email)) {
        newErrors.email = 'Please enter a valid email address'
      }
    } else if (form.contactMethod === 'whatsapp') {
      const phoneRegex = /^[+]?[\d\s()-]{7,20}$/
      if (!form.whatsapp.trim() || !phoneRegex.test(form.whatsapp)) {
        newErrors.whatsapp = 'Please enter a valid phone number'
      }
    }

    // Validate links
    const linkErrors: string[] = []
    form.links.forEach((link) => {
      if (link.trim()) {
        try {
          new URL(link)
          linkErrors.push('')
        } catch {
          linkErrors.push('Please enter a valid URL')
        }
      } else {
        linkErrors.push('')
      }
    })
    if (linkErrors.some((e) => e !== '')) {
      newErrors.links = linkErrors
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  /* ---- Submit ---- */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return

    setIsSubmitting(true)

    try {
      const formData = new FormData()
      formData.append('fullName', form.fullName)
      formData.append('skills', form.skills)
      formData.append('contactMethod', form.contactMethod!)

      if (form.contactMethod === 'email') {
        formData.append('email', form.email)
      } else {
        formData.append('whatsapp', form.whatsapp)
      }

      if (form.file) {
        formData.append('file', form.file)
      }

      form.links.forEach((link, i) => {
        if (link.trim()) formData.append(`link_${i + 1}`, link.trim())
      })

      const response = await fetch(FORMSPREE_ENDPOINT, {
        method: 'POST',
        body: formData,
        headers: { Accept: 'application/json' },
      })

      if (response.ok) {
        setIsSuccess(true)
        setForm(INITIAL_FORM)
      } else {
        throw new Error('Submission failed')
      }
    } catch {
      setErrors({ fullName: 'Something went wrong. Please try again.' })
    } finally {
      setIsSubmitting(false)
    }
  }

  /* ---- Scroll to form ---- */
  const scrollToForm = () => {
    formRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  /* ---- Render ---- */
  return (
    <div className="min-h-screen bg-white">
      {/* ====== HERO ====== */}
      <header className="relative bg-white border-t-4 border-[#0057A4]">
        <div className="max-w-[680px] mx-auto px-6 pt-16 pb-8 text-center">
          {/* Logo */}
          <img
            src="/logo.jpg"
            alt="School Box Africa"
            className="w-[120px] h-[120px] mx-auto rounded-xl shadow-md object-cover mb-8"
          />

          {/* Headline */}
          <h1 className="font-heading text-[36px] sm:text-[48px] font-extrabold text-[#1A1A2E] leading-[1.1] tracking-tight mb-5">
            Volunteer with School Box Africa
          </h1>

          {/* Subline */}
          <p className="text-[16px] sm:text-[18px] text-[#6B7280] font-normal leading-relaxed max-w-[520px] mx-auto mb-8">
            Share your skills. Shape futures. Help us bring vocational education
            to communities across Africa.
          </p>

          {/* Scroll indicator */}
          <button
            onClick={scrollToForm}
            className="inline-flex flex-col items-center text-[#0057A4] hover:text-[#004B8D] transition-colors cursor-pointer"
            aria-label="Scroll to form"
          >
            <span className="text-[12px] font-medium mb-1">Get Started</span>
            <ChevronDown className="w-5 h-5 scroll-chevron" />
          </button>
        </div>
      </header>

      {/* ====== FORM SECTION ====== */}
      <main className="bg-[#F7F8FA]" ref={formRef}>
        <div className="max-w-[680px] mx-auto px-6 py-20 sm:py-24">
          {isSuccess ? (
            /* ---- Success State ---- */
            <div className="text-center py-16">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-[#10B981]/10 mb-6">
                <CheckCircle2 className="w-10 h-10 text-[#10B981]" />
              </div>
              <h2 className="font-heading text-[28px] sm:text-[32px] font-bold text-[#1A1A2E] mb-3">
                Application Sent!
              </h2>
              <p className="text-[16px] text-[#6B7280] max-w-[400px] mx-auto">
                Thank you for offering your skills. We'll review your
                application and be in touch soon via your preferred contact
                method.
              </p>
              <button
                onClick={() => {
                  setIsSuccess(false)
                  setForm(INITIAL_FORM)
                  setErrors({})
                }}
                className="mt-8 text-[#0057A4] font-semibold text-[14px] hover:text-[#004B8D] transition-colors cursor-pointer"
              >
                Submit another application
              </button>
            </div>
          ) : (
            /* ---- Form ---- */
            <form onSubmit={handleSubmit} noValidate>
              <div ref={fieldsRef} className="space-y-6">
                {/* --- Field 1: Full Name --- */}
                <div className="form-field">
                  <label
                    htmlFor="fullName"
                    className="block text-[14px] font-semibold text-[#1A1A2E] mb-2"
                  >
                    Full Name <span className="text-[#EF4444]">*</span>
                  </label>
                  <input
                    id="fullName"
                    type="text"
                    value={form.fullName}
                    onChange={(e) => updateField('fullName', e.target.value)}
                    placeholder="Enter your full name"
                    className={`w-full h-12 px-4 rounded-lg border bg-white text-[15px] text-[#1A1A2E] placeholder:text-[#9CA3AF] outline-none transition-all duration-200 focus:border-[#0057A4] focus:shadow-[0_0_0_3px_rgba(0,87,164,0.1)] ${
                      errors.fullName
                        ? 'border-[#EF4444]'
                        : 'border-[#E5E7EB]'
                    }`}
                  />
                  {errors.fullName && (
                    <p className="mt-1.5 text-[12px] text-[#EF4444]">
                      {errors.fullName}
                    </p>
                  )}
                </div>

                {/* --- Field 2: Skills --- */}
                <div className="form-field">
                  <label
                    htmlFor="skills"
                    className="block text-[14px] font-semibold text-[#1A1A2E] mb-1"
                  >
                    What skills can you offer?{' '}
                    <span className="text-[#EF4444]">*</span>
                  </label>
                  <p className="text-[12px] text-[#6B7280] mb-2">
                    Describe your skills, experience, and how you'd like to
                    contribute.
                  </p>
                  <textarea
                    id="skills"
                    value={form.skills}
                    onChange={(e) => updateField('skills', e.target.value)}
                    placeholder="e.g., I have 5 years of experience in agricultural engineering and I'd love to help create course content..."
                    rows={5}
                    className={`w-full px-4 py-3 rounded-lg border bg-white text-[15px] text-[#1A1A2E] placeholder:text-[#9CA3AF] outline-none resize-none transition-all duration-200 focus:border-[#0057A4] focus:shadow-[0_0_0_3px_rgba(0,87,164,0.1)] ${
                      errors.skills
                        ? 'border-[#EF4444]'
                        : 'border-[#E5E7EB]'
                    }`}
                  />
                  {errors.skills && (
                    <p className="mt-1.5 text-[12px] text-[#EF4444]">
                      {errors.skills}
                    </p>
                  )}
                </div>

                {/* --- Field 3: Contact Method --- */}
                <div className="form-field">
                  <label className="block text-[14px] font-semibold text-[#1A1A2E] mb-3">
                    How should we contact you?{' '}
                    <span className="text-[#EF4444]">*</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Email Card */}
                    <button
                      type="button"
                      onClick={() => handleContactMethodSelect('email')}
                      className={`relative flex flex-col items-center p-5 rounded-lg border-2 transition-all duration-200 cursor-pointer text-left ${
                        form.contactMethod === 'email'
                          ? 'border-[#0057A4] bg-[#E6F0FA] shadow-[0_2px_8px_rgba(0,87,164,0.1)]'
                          : 'border-[#E5E7EB] bg-white hover:bg-[#F7F8FA]'
                      }`}
                    >
                      {form.contactMethod === 'email' && (
                        <div className="absolute top-3 right-3 w-4 h-4 rounded-full bg-[#0057A4] flex items-center justify-center">
                          <CheckCircle2 className="w-3 h-3 text-white" />
                        </div>
                      )}
                      <Mail
                        className={`w-7 h-7 mb-2 ${
                          form.contactMethod === 'email'
                            ? 'text-[#0057A4]'
                            : 'text-[#6B7280]'
                        }`}
                      />
                      <span
                        className={`text-[15px] font-semibold ${
                          form.contactMethod === 'email'
                            ? 'text-[#0057A4]'
                            : 'text-[#1A1A2E]'
                        }`}
                      >
                        Email
                      </span>
                      <span className="text-[12px] text-[#6B7280] mt-1 text-center">
                        We'll send you an invitation to book a call
                      </span>
                    </button>

                    {/* WhatsApp Card */}
                    <button
                      type="button"
                      onClick={() => handleContactMethodSelect('whatsapp')}
                      className={`relative flex flex-col items-center p-5 rounded-lg border-2 transition-all duration-200 cursor-pointer text-left ${
                        form.contactMethod === 'whatsapp'
                          ? 'border-[#0057A4] bg-[#E6F0FA] shadow-[0_2px_8px_rgba(0,87,164,0.1)]'
                          : 'border-[#E5E7EB] bg-white hover:bg-[#F7F8FA]'
                      }`}
                    >
                      {form.contactMethod === 'whatsapp' && (
                        <div className="absolute top-3 right-3 w-4 h-4 rounded-full bg-[#0057A4] flex items-center justify-center">
                          <CheckCircle2 className="w-3 h-3 text-white" />
                        </div>
                      )}
                      <Phone
                        className={`w-7 h-7 mb-2 ${
                          form.contactMethod === 'whatsapp'
                            ? 'text-[#0057A4]'
                            : 'text-[#6B7280]'
                        }`}
                      />
                      <span
                        className={`text-[15px] font-semibold ${
                          form.contactMethod === 'whatsapp'
                            ? 'text-[#0057A4]'
                            : 'text-[#1A1A2E]'
                        }`}
                      >
                        WhatsApp
                      </span>
                      <span className="text-[12px] text-[#6B7280] mt-1 text-center">
                        We'll message you to arrange a call
                      </span>
                    </button>
                  </div>
                  {errors.contactMethod && (
                    <p className="mt-1.5 text-[12px] text-[#EF4444]">
                      {errors.contactMethod}
                    </p>
                  )}
                </div>

                {/* --- Field 4: Contact Details (conditional) --- */}
                {form.contactMethod === 'email' && (
                  <div className="form-field animate-in fade-in slide-in-from-top-2 duration-300">
                    <label
                      htmlFor="email"
                      className="block text-[14px] font-semibold text-[#1A1A2E] mb-2"
                    >
                      Email Address{' '}
                      <span className="text-[#EF4444]">*</span>
                    </label>
                    <input
                      id="email"
                      type="email"
                      value={form.email}
                      onChange={(e) => updateField('email', e.target.value)}
                      placeholder="your@email.com"
                      className={`w-full h-12 px-4 rounded-lg border bg-white text-[15px] text-[#1A1A2E] placeholder:text-[#9CA3AF] outline-none transition-all duration-200 focus:border-[#0057A4] focus:shadow-[0_0_0_3px_rgba(0,87,164,0.1)] ${
                        errors.email
                          ? 'border-[#EF4444]'
                          : 'border-[#E5E7EB]'
                      }`}
                    />
                    {errors.email && (
                      <p className="mt-1.5 text-[12px] text-[#EF4444]">
                        {errors.email}
                      </p>
                    )}
                  </div>
                )}

                {form.contactMethod === 'whatsapp' && (
                  <div className="form-field animate-in fade-in slide-in-from-top-2 duration-300">
                    <label
                      htmlFor="whatsapp"
                      className="block text-[14px] font-semibold text-[#1A1A2E] mb-2"
                    >
                      WhatsApp Number{' '}
                      <span className="text-[#EF4444]">*</span>
                    </label>
                    <input
                      id="whatsapp"
                      type="tel"
                      value={form.whatsapp}
                      onChange={(e) =>
                        updateField('whatsapp', e.target.value)
                      }
                      placeholder="+1 234 567 8900"
                      className={`w-full h-12 px-4 rounded-lg border bg-white text-[15px] text-[#1A1A2E] placeholder:text-[#9CA3AF] outline-none transition-all duration-200 focus:border-[#0057A4] focus:shadow-[0_0_0_3px_rgba(0,87,164,0.1)] ${
                        errors.whatsapp
                          ? 'border-[#EF4444]'
                          : 'border-[#E5E7EB]'
                      }`}
                    />
                    {errors.whatsapp && (
                      <p className="mt-1.5 text-[12px] text-[#EF4444]">
                        {errors.whatsapp}
                      </p>
                    )}
                  </div>
                )}

                {/* --- Field 5: Portfolio --- */}
                <div className="form-field">
                  <label className="block text-[14px] font-semibold text-[#1A1A2E] mb-1">
                    Showcase your work (optional)
                  </label>
                  <p className="text-[12px] text-[#6B7280] mb-3">
                    Upload a PDF or share links to your portfolio, LinkedIn, or
                    past work.
                  </p>

                  {/* File Upload Zone */}
                  <div
                    onDragOver={(e) => {
                      e.preventDefault()
                      setIsDragOver(true)
                    }}
                    onDragLeave={() => setIsDragOver(false)}
                    onDrop={handleFileDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`relative w-full h-[120px] rounded-lg border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all duration-150 ${
                      form.file
                        ? 'border-[#10B981] bg-[#ECFDF5]'
                        : isDragOver
                        ? 'border-[#0057A4] bg-[#E6F0FA] scale-[1.01]'
                        : 'border-[#E5E7EB] bg-white hover:border-[#0057A4] hover:bg-[#F7F8FA]'
                    }`}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".pdf"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                    {form.file ? (
                      <div className="flex items-center gap-3 px-4">
                        <FileText className="w-6 h-6 text-[#10B981] shrink-0" />
                        <span className="text-[14px] text-[#1A1A2E] font-medium truncate max-w-[300px]">
                          {form.file.name}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            removeFile()
                          }}
                          className="ml-2 p-1 rounded-full hover:bg-[#10B981]/10 transition-colors cursor-pointer"
                        >
                          <X className="w-4 h-4 text-[#6B7280]" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <Upload
                          className={`w-6 h-6 mb-2 ${
                            isDragOver ? 'text-[#0057A4]' : 'text-[#9CA3AF]'
                          }`}
                        />
                        <span className="text-[14px] text-[#6B7280]">
                          Drop your PDF here, or click to browse
                        </span>
                        <span className="text-[11px] text-[#9CA3AF] mt-1">
                          PDF only, max 5MB
                        </span>
                      </>
                    )}
                  </div>
                  {errors.file && (
                    <p className="mt-1.5 text-[12px] text-[#EF4444]">
                      {errors.file}
                    </p>
                  )}

                  {/* Link Inputs */}
                  <div className="mt-4 space-y-3">
                    {form.links.map((link, index) => (
                      <div key={index} className="flex gap-2">
                        <div className="flex-1 relative">
                          <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                          <input
                            type="url"
                            value={link}
                            onChange={(e) =>
                              updateLink(index, e.target.value)
                            }
                            placeholder="https://your-portfolio.com"
                            className={`w-full h-11 pl-10 pr-4 rounded-lg border bg-white text-[14px] text-[#1A1A2E] placeholder:text-[#9CA3AF] outline-none transition-all duration-200 focus:border-[#0057A4] focus:shadow-[0_0_0_3px_rgba(0,87,164,0.1)] ${
                              errors.links?.[index]
                                ? 'border-[#EF4444]'
                                : 'border-[#E5E7EB]'
                            }`}
                          />
                          {errors.links?.[index] && (
                            <p className="mt-1 text-[11px] text-[#EF4444]">
                              {errors.links[index]}
                            </p>
                          )}
                        </div>
                        {form.links.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeLink(index)}
                            className="self-start p-2.5 rounded-lg border border-[#E5E7EB] hover:bg-[#F7F8FA] transition-colors cursor-pointer shrink-0"
                          >
                            <X className="w-4 h-4 text-[#6B7280]" />
                          </button>
                        )}
                      </div>
                    ))}

                    {form.links.length < 3 && (
                      <button
                        type="button"
                        onClick={addLinkField}
                        className="inline-flex items-center gap-1.5 text-[13px] font-medium text-[#0057A4] hover:text-[#004B8D] transition-colors cursor-pointer"
                      >
                        <Globe className="w-3.5 h-3.5" />
                        + Add another link
                      </button>
                    )}
                  </div>
                </div>

                {/* --- Field 6: Submit --- */}
                <div className="form-field pt-4">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto sm:min-w-[240px] h-[52px] px-8 bg-[#0057A4] text-white font-semibold text-[16px] rounded-lg transition-all duration-200 hover:bg-[#004B8D] hover:-translate-y-px hover:shadow-[0_4px_12px_rgba(0,87,164,0.25)] disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:translate-y-0 disabled:hover:shadow-none cursor-pointer flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Sending...</span>
                      </>
                    ) : (
                      'Submit Application'
                    )}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </main>

      {/* ====== FOOTER ====== */}
      <footer className="bg-white border-t border-[#E5E7EB]">
        <div className="max-w-[680px] mx-auto px-6 py-8 text-center">
          <p className="text-[14px] font-semibold text-[#1A1A2E] mb-1">
            School Box Africa
          </p>
          <p className="text-[12px] text-[#9CA3AF]">
            Made with care for communities across Africa.
          </p>
        </div>
      </footer>
    </div>
  )
}

export default App
